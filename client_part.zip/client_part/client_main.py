import socket
import time
from client_part import client
import RecordAudio


host = socket.gethostname()
port = 8888
buffer_size = 1024

client1 = client.MyClient(host, port)
print('Connection Established')

RecordAudio.record_audio()
time.sleep(3)

file = open('output.wav', 'rb')
client1.send_file(file, buffer_size)
file.close()


